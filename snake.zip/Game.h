#pragma once
class Game
{
	private:
		void Setup();
		void Draw();
		void Logic();
		void Input();
		void getRandom();
		void horisontalline();
		void control();
		void makeTail();
	public:
		void Letsplay();
};

